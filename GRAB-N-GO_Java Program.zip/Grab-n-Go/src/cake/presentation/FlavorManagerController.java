package cake.presentation;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.domain.CakeType;
import cake.domain.Topping;
import cake.service.AdminService;
import cake.service.ServiceException;
import cake.service.StudentService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.util.Callback;

public class FlavorManagerController {
	private static final boolean String = false;

	@FXML
	protected TextField textFieldAdd;

	@FXML
	protected ChoiceBox selectAddSize;

	@FXML
	protected Label labelDeleteSize;

	@FXML
	protected Label labelAddSize;

	@FXML
	protected TableView<CakeType> tableViewSize = new TableView<>();

	@FXML
	protected TableColumn tableColumnSize = new TableColumn();

	@FXML
	protected ChoiceBox<String> choiceBoxSize = new ChoiceBox();

	@FXML
	protected Text actiontarget;

	private AdminService adminService;
	private StudentService studentService;

	public FlavorManagerController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();

		try {
			initialize();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	protected void handleButtonShop() throws IOException {
		Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");

	}

	@FXML
	protected void handleButtonAdmin() throws IOException {
		Main.getInstance().changeStage("/cake/presentation/Admin.fxml");

	}

	@FXML
	protected void handleButtonAddSize() throws IOException, ServiceException {
		if (textFieldAdd.getText().isEmpty() || textFieldAdd.equals(null)) {
			actiontarget.setText("Enter Valid Text");
		} else {
			adminService.addCakeSize(textFieldAdd.getText());
			System.out.println("Added Size Successfully");
			Main.getInstance().changeStage("/cake/presentation/FlavorManager.fxml");
		}

	}

	@FXML
	protected void changeStateTopping() throws IOException {
		Main.getInstance().changeStage("/cake/presentation/ToppingManager.fxml");
	}

	@FXML
	protected void changeStateSize() throws IOException {
		Main.getInstance().changeStage("/cake/presentation/FlavorManager.fxml");

	}

	@FXML
	protected void changeStateDay() throws IOException {
		Main.getInstance().changeStage("/cake/presentation/DeliveryManager.fxml");

	}

	@FXML
	protected void changeStateOrder() throws IOException {
		Main.getInstance().changeStage("/cake/presentation/OrderManager.fxml");
	}

	@SuppressWarnings("unchecked")
	@FXML
	public void initialize() throws ServiceException {
		Set<CakeType> sizes = studentService.getCakeTypes();
		Set<String> sizeName = new HashSet<String>();
		for (CakeType size : sizes) {
			sizeName.add(size.getflavour());
		}
		ObservableList<String> data1 = FXCollections.observableArrayList(sizeName);
		choiceBoxSize.setItems(data1);

		ObservableList<CakeType> data = FXCollections.observableArrayList(sizes);
		PropertyValueFactory a = new PropertyValueFactory("flavour");
		tableColumnSize.setCellValueFactory(new PropertyValueFactory("flavour"));
		tableViewSize.setItems(data);
	}

	@FXML
	protected void handleButtonRemoveSize() throws IOException {
		try {
			String removeTopping = choiceBoxSize.toString();
			System.out.println("Remove size" + removeTopping);
			adminService.removeCakeSize(choiceBoxSize.getValue().toString());
			System.out.println("Removed Successfully");
			Main.getInstance().changeStage("/cake/presentation/FlavorManager.fxml");
		} catch (ServiceException e) {
		}

	}

}
