package cake.presentation;

import java.io.IOException;
import java.util.Set;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.domain.CakeType;
import cake.domain.Topping;
import cake.service.AdminService;
import cake.service.ServiceException;
import cake.service.StudentService; 
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class LoginController {


	@FXML
    protected Text actiontarget;
    @FXML
    protected PasswordField passwordField;
    @FXML
    protected TextField loginField;
    @FXML
    protected Button btn1;
    @FXML
    protected Button cakeShop;
    
    private Main application;
    private AdminService adminService;
    private StudentService studentService;
	
	public LoginController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();
	}
    
    public void setApp(Main application){
        this.application = application;
    }    
    @FXML protected void handleSubmitButtonLogin() throws IOException, ServiceException{

    	System.out.println("Logged in Successfully");
    	System.out.println("Username::"+loginField.getText());
    	System.out.println("Password::"+passwordField.getText());
        if((loginField.getText().equals("admin"))&&(passwordField.getText().equals("1234"))){
        	Main.getInstance().changeStage("/cake/presentation/Admin.fxml");
        } /*else if((loginField.getText().equals("student"))&&(passwordField.getText().equals("1234"))){
        	Set<Topping> toppings =studentService.getToppings();
        	Set<CakeSize> sizes = studentService.getCakeSizes();
        	Main.getInstance().changeStage("/cake/presentation/MakeCake.fxml");
        }    */
        else
        {
        	 actiontarget.setText("Enter Valid Credentials!");
        }
   }
    
    @FXML protected void handleSubmitButtonEnter() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");
    }
    
    
}
