package cake.presentation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.service.AdminService;
import cake.service.CakeOrderData;
import cake.service.ServiceException;
import cake.service.StudentService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;


public class CakeShopController {

	
	@FXML
    protected Text actiontarget;
    @FXML
    protected Text labelStatusOrders;
    @FXML
    protected TextField textFieldLocation;
    @FXML
    protected Button btnMakeCake;
    @FXML
    protected Button btnCakeShop;
    @FXML
    protected Button btnLogin;
    
    @FXML 
	protected TableColumn tableColumnOrder = new  TableColumn();
	
	@FXML 
	protected TableColumn tableColumnStatus = new  TableColumn();
	
	@FXML 
	protected TableColumn tableColumnRoom = new  TableColumn();

	@FXML
	protected TableView tableViewCake = new TableView();
	
    private AdminService adminService;
	private StudentService studentService;
	
	public CakeShopController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();
	}
    
	@FXML protected void handleButtonMakeCake() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/MakeCake.fxml");
	
	}
	@FXML protected void handleButtonCakeShop() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");
		
	}
	@FXML protected void handleButtonLogin() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/Login.fxml");
	
	}
	
	
	@FXML protected void handleButtonCheckStatus() throws IOException, NumberFormatException, ServiceException{
		
		String location=(textFieldLocation.getText().toString());
		List<CakeOrderData> cakeOrders1 = studentService.getOrderStatus(location);
		List<String> cakeOrders11 = new ArrayList<String>();
		for (CakeOrderData s: cakeOrders1){
			cakeOrders11.add(s.toString());
		}

		tableColumnOrder.setCellValueFactory(new PropertyValueFactory("id"));
		tableColumnRoom.setCellValueFactory(new PropertyValueFactory("Location"));
		tableColumnStatus.setCellValueFactory(new PropertyValueFactory("statusString"));
		ObservableList<CakeOrderData> data1 = FXCollections.observableArrayList(cakeOrders1);
		
			
		tableViewCake.setItems(data1);
	}

	
	
	  
	
}	
