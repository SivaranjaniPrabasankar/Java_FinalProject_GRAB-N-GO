package cake.presentation;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.domain.CakeType;
import cake.domain.Topping;
import cake.service.AdminService;
import cake.service.CakeOrderData;
import cake.service.ServiceException;
import cake.service.StudentService;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class AdminController {
	
	@FXML
    protected Button btn1;
    @FXML
    protected Button btn2;
    @FXML
    protected Button btn3;
    @FXML
    protected Button btn4;
    @FXML
    protected Button btn5;
    @FXML
    protected Button btn6;
    
    private AdminService adminService;
    private StudentService studentService;
	
	public AdminController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();
	}
	
    @FXML protected void handleButtonTopping() throws IOException, ServiceException{
    	//Set<Topping> toppings =studentService.getToppings();
        Main.getInstance().changeStage("/cake/presentation/ToppingManager.fxml");
   }
    @FXML protected void handleButtonSize() throws IOException, ServiceException{
    	//Set<CakeSize> sizes =studentService.getCakeSizes();
        Main.getInstance().changeStage("/cake/presentation/FlavorManager.fxml");
   }
    @FXML protected void handleButtonDay() throws IOException, ServiceException{
    	//int currentDay = adminService.getCurrentDay();
    	//List<CakeOrderData> cakeOrders = adminService.getOrdersByDay(currentDay);
        Main.getInstance().changeStage("/cake/presentation/DeliveryManager.fxml");
   }
    @FXML protected void handleButtonOrder() throws IOException, ServiceException{
    	//List<CakeOrderData> bakedOrders = adminService.getTodaysOrdersByStatus(2);
    	//List<CakeOrderData> inOven = adminService.getTodaysOrdersByStatus(1);
        Main.getInstance().changeStage("/cake/presentation/OrderManager.fxml");
   }
    @FXML protected void handleButtonCake() throws IOException{
        Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");
       
   }
    @FXML protected void handleButtonHome() throws IOException{
        Main.getInstance().changeStage("/cake/presentation/Login.fxml");
   }
}
