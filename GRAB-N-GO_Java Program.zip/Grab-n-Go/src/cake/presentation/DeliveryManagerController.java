package cake.presentation;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.domain.CakeType;
import cake.service.AdminService;
import cake.service.CakeOrderData;
import cake.service.ServiceException;
import cake.service.StudentService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class DeliveryManagerController {

	@FXML
	protected Button btnNextDay;
	
	@FXML
	protected Label labelDayOrder;
	
	@FXML
	protected Label labelDayList;
	
	@FXML
	protected TableView tableViewDay = new TableView();
	
	@FXML
	protected TableView tableViewSize = new TableView();
	
	@FXML 
	protected TableColumn tableColumnOrder = new  TableColumn();
	
	@FXML 
	protected TableColumn tableColumnSize = new  TableColumn();
	
	@FXML 
	protected TableColumn tableColumnRoom = new  TableColumn();
	
	@FXML 
	protected TableColumn tableColumnStatus = new  TableColumn();
	
	
	private AdminService adminService;
	private StudentService studentService;
	
	public DeliveryManagerController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();
		
		try {
			initialize();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML protected void handleButtonShop() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");
		
	}
	@FXML protected void handleButtonAdmin() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/Admin.fxml");
		
	}
	@FXML protected void handleButtonNextDay() throws IOException, ServiceException{
		adminService.advanceDay();
		int currentDay = adminService.getCurrentDay();
		Main.getInstance().changeStage("/cake/presentation/DeliveryManager.fxml");
	}
	
	@FXML public void initialize() throws ServiceException{
		int currentDay = adminService.getCurrentDay();
    	List<CakeOrderData> cakeOrders = adminService.getOrdersByDay(currentDay);
		
    	
		ObservableList<CakeOrderData> data = FXCollections.observableArrayList(cakeOrders);

		/*Set<String> sizeName = new HashSet<String>();
		for (CakeOrderData order : cakeOrders)
		{
			sizeName.add(order.getCakeSize().getSizeName());
		}
		System.out.println("Size name " + sizeName);
		ObservableList<String> data1 = FXCollections.observableArrayList(sizeName);
		*/
		tableColumnOrder.setCellValueFactory(new PropertyValueFactory("id"));
		
	//	tableColumnSize.setCellValueFactory(new PropertyValueFactory("sizeName"));
		
		tableColumnRoom.setCellValueFactory(new PropertyValueFactory("Location"));
		
		tableColumnStatus.setCellValueFactory(new PropertyValueFactory("status"));
		
		
		System.out.println("find size data" + data);
		
		tableViewDay.setItems(data);
		//tableViewSize.setItems(data1);
	}
	
	@FXML protected void changeStateTopping() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/ToppingManager.fxml");
	}
	
	@FXML protected void changeStateSize() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/FlavorManager.fxml");
	
	}
	
	@FXML protected void changeStateDay() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/DeliveryManager.fxml");
	
	}
	
	@FXML protected void changeStateOrder() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/OrderManager.fxml");
	}
	
}
