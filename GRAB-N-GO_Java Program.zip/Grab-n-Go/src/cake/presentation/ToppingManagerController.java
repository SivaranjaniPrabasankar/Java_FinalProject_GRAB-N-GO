package cake.presentation;

import java.io.IOException;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.dao.CakeOrderDAO;
import cake.domain.Topping;
import cake.service.AdminService;
import cake.service.ServiceException;
import cake.service.StudentService;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;

public class ToppingManagerController {
	
	@FXML
	protected TextField textFieldAdd;
	
	@FXML
	protected ChoiceBox selectAddTop;
	
	@FXML
	protected Label labelDeleteTop;
	
	@FXML
	protected Label labelAddTop;
	
	@FXML
	protected TableView<Topping> tableviewToppings = new TableView<>();
	
	@FXML 
	protected TableColumn tableColumnToppings = new  TableColumn();
	
	@FXML 
	protected ChoiceBox<String> choiceBoxTop =new ChoiceBox<>();
	
	@FXML
    protected Text actiontarget;
	
	private AdminService adminService;
	private StudentService studentService;
	private ObservableList<Topping> data;
	
	public ToppingManagerController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();
		try {
			initialize();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 
	}
	
	@FXML protected void handleButtonShop() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");
		
	}
	@FXML protected void handleButtonAdmin() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/Admin.fxml");
		
	}
	@FXML protected void handleButtonAddTop() throws IOException{
		try {
			if(textFieldAdd.getText().equals(null) || textFieldAdd.getText().isEmpty()){
				actiontarget.setText("Enter Valid Toppings");
			}else
			{
				adminService.addTopping(textFieldAdd.getText());
				System.out.println("Added Successfully");
				Main.getInstance().changeStage("/cake/presentation/ToppingManager.fxml");
			}
			
		} catch (ServiceException e) {
		}
	}
	@FXML protected void handleButtonRemoveTop() throws IOException{
		try {
			String removeTopping = choiceBoxTop.toString();
			System.out.println("Remove Toppings" +removeTopping);
			adminService.removeTopping(choiceBoxTop.getValue().toString());
			 
			System.out.println("Removed Successfully");
			Main.getInstance().changeStage("/cake/presentation/ToppingManager.fxml");
		} catch (ServiceException e) {
		}
	}
	
	
	@FXML public void initialize() throws ServiceException{
		Set<Topping> toppings =studentService.getToppings();
		Set<String> toppingName = new HashSet<String>();
		for (Topping topping : toppings)
		{
		 	toppingName.add(topping.getToppingName());
		}
		ObservableList<String> names = FXCollections.observableArrayList(toppingName);
		choiceBoxTop.setItems(names);
			
		ObservableList<Topping> data = FXCollections.observableArrayList(toppings);
		tableColumnToppings.setCellValueFactory(new PropertyValueFactory("toppingName"));
		System.out.println("find toppings data" + data);
		tableviewToppings.setItems(data);
	}
	
	@FXML protected void changeStateTopping() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/ToppingManager.fxml");
	}
	
	@FXML protected void changeStateSize() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/FlavorManager.fxml");
	
	}
	
	@FXML protected void changeStateDay() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/DeliveryManager.fxml");
	
	}
	
	@FXML protected void changeStateOrder() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/OrderManager.fxml");
	}
	
}
