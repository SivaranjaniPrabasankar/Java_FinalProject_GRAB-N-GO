package cake.presentation;

import java.io.IOException;
import java.util.List;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.service.AdminService;
import cake.service.CakeOrderData;
import cake.service.ServiceException;
import cake.service.StudentService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class OrderManagerController {

	@FXML
	protected TableView<CakeOrderData> tableViewOrder1= new TableView();
	
	@FXML 
	protected TableColumn tableColumnOrder1 = new  TableColumn();
	
	/*@FXML 
	protected TableColumn tableColumnSize1 = new  TableColumn();
	*/
	@FXML 
	protected TableColumn tableColumnRoom1 = new  TableColumn();
	
	@FXML 
	protected TableColumn tableColumnStatus1 = new  TableColumn();

	@FXML
	protected TableView<CakeOrderData> tableViewOrder2 = new TableView();
	
	@FXML 
	protected TableColumn tableColumnOrder2 = new  TableColumn();
	
	/*@FXML 
	protected TableColumn tableColumnSize2 = new  TableColumn();
	*/
	@FXML 
	protected TableColumn tableColumnRoom2 = new  TableColumn();
	
	@FXML 
	protected TableColumn tableColumnStatus2 = new  TableColumn();
	
	@FXML
	protected Label labelBakedDelievered;
	
	@FXML
	protected Label labelBakedPreparing;
	
	private AdminService adminService;
	private StudentService studentService;
	
	public OrderManagerController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();
		
		try {
			initialize();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML public void initialize() throws ServiceException{
		List<CakeOrderData> bakedOrders = adminService.getTodaysOrdersByStatus(2);
    	List<CakeOrderData> inOven = adminService.getTodaysOrdersByStatus(1);
		
		ObservableList<CakeOrderData> data1 = FXCollections.observableArrayList(bakedOrders);
		ObservableList<CakeOrderData> data2 = FXCollections.observableArrayList(inOven);
		
		
		tableColumnOrder1.setCellValueFactory(new PropertyValueFactory("id"));
		//tableColumnSize1.setCellValueFactory(new PropertyValueFactory("cakeSize"));
		tableColumnRoom1.setCellValueFactory(new PropertyValueFactory("Location"));
		tableColumnStatus1.setCellValueFactory(new PropertyValueFactory("status"));
		
		tableViewOrder1.setItems(data1);
		
		tableColumnOrder2.setCellValueFactory(new PropertyValueFactory("id"));
		//tableColumnSize2.setCellValueFactory(new PropertyValueFactory("cakeSize"));
		tableColumnRoom2.setCellValueFactory(new PropertyValueFactory("Location"));
		tableColumnStatus2.setCellValueFactory(new PropertyValueFactory("status"));
		
		System.out.println("find order data" + data1);
		
		tableViewOrder2.setItems(data2);
		
	}
	
	@FXML protected void handleButtonShop() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");
		
	}
	@FXML protected void handleButtonAdmin() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/Admin.fxml");
		
	}
	@FXML protected void handleButtonMakeOldestReady() throws IOException{
		try {
			adminService.markNextOrderReady();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Main.getInstance().changeStage("/cake/presentation/OrderManager.fxml");
	}
	@FXML protected void handleButtonInitializeDB() throws IOException{
		try {
			adminService.initializeDb();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Main.getInstance().changeStage("/cake/presentation/OrderManager.fxml");
		
	}
	
	@FXML protected void changeStateTopping() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/ToppingManager.fxml");
	}
	
	@FXML protected void changeStateSize() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/FlavorManager.fxml");
	
	}
	
	@FXML protected void changeStateDay() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/DeliveryManager.fxml");
	
	}
	
	@FXML protected void changeStateOrder() throws IOException{
		Main.getInstance().changeStage("/cake/presentation/OrderManager.fxml");
	}
	
	
}
