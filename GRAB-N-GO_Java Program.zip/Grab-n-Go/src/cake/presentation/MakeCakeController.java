package cake.presentation;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import cake.Main;
import cake.config.CakeSystemConfig;
import cake.domain.CakeType;
import cake.domain.Topping;
import cake.service.AdminService;
import cake.service.CakeOrderData;
import cake.service.ServiceException;
import cake.service.StudentService;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuButton;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.event.Event;
import javafx.event.EventHandler;

public class MakeCakeController {

	@FXML
	private Label labelTopping;
	@FXML
	private Label labelSize;
	@FXML
	private Button btnCakeShop;
	@FXML
	private Button btnLogin;
	@FXML
	private TextField textFieldRMakeRoom;
	@FXML
	private Button btnOrderNow;
	@FXML
	private Text message;

	@FXML
	protected ChoiceBox<String> choiceBoxSize1 = new ChoiceBox();

	@FXML
	protected ChoiceBox<String> choiceBoxSize2 = new ChoiceBox();
	@FXML
	protected ChoiceBox<String> choiceBoxLocation = new ChoiceBox();

	@FXML
	ListView<String> listViewTop = new ListView<String>();
	@FXML
	ListView<String> listViewSize = new ListView<String>();

	private AdminService adminService;
	private StudentService studentService;

	public MakeCakeController() {
		CakeSystemConfig.configureServices();
		adminService = CakeSystemConfig.getAdminService();
		studentService = CakeSystemConfig.getStudentService();

		try {
			initialize();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@FXML
	public void initialize() throws ServiceException {

		Set<Topping> toppings = studentService.getToppings();
		Set<String> toppingName = new HashSet<String>();
		for (Topping topping : toppings) {
			toppingName.add(topping.getToppingName());
		}
		ObservableList<String> data1 = FXCollections.observableArrayList(toppingName);
		choiceBoxSize1.setItems(data1);
		listViewTop.setItems(data1);
		listViewTop.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		listViewTop.setOnMouseClicked(new EventHandler<Event>() {
			@Override
			public void handle(Event event) {
				ObservableList<String> selectedItemsTop = listViewTop.getSelectionModel().getSelectedItems();

				for (String s : selectedItemsTop) {
					System.out.println("selected item " + s + "  items" + selectedItemsTop);
				}
			}

		});
		Set<CakeType> sizes = studentService.getCakeTypes();
		Set<String> sizeName = new HashSet<String>();
		for (CakeType size : sizes) {
			sizeName.add(size.getflavour());
		}
		ObservableList<String> data2 = FXCollections.observableArrayList(sizeName);
		choiceBoxSize2.setItems(data2);
		listViewSize.setItems(data2);
		listViewSize.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		listViewSize.setOnMouseClicked(new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				ObservableList<String> selectedItemssize = listViewSize.getSelectionModel().getSelectedItems();
				for (String s : selectedItemssize) {
					System.out.println("selected item size " + s + "selectedItemssize" + selectedItemssize);
				}
			}
		});
		choiceBoxLocation.getItems().addAll("Magnolia", "Yolk", "Wild Berries", "Cake&Cream", "Dunkins", "Amy Beck",
				"Molly's", "Sprinkles");

	}

	// Event Listener on Button[#btnCakeShop].onAction
	@FXML
	public void handleButtonCakeShop(ActionEvent event) {
		try {
			Main.getInstance().changeStage("/cake/presentation/CakeShop.fxml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// Event Listener on Button[#btnLogin].onAction
	@FXML
	public void handleButtonLogin(ActionEvent event) {
		try {
			Main.getInstance().changeStage("/cake/presentation/Login.fxml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// Event Listener on Button[#btnOrderNow].onAction
	@FXML
	public void handleButtonOrderNow(ActionEvent event)
			throws ServiceException, InstantiationException, IllegalAccessException, ClassNotFoundException {

		ObservableList<String> toplist = listViewTop.getSelectionModel().getSelectedItems();

		Set<Topping> top = new HashSet<Topping>();

		top = studentService.getToppingsType(toplist);

		String sizelist = choiceBoxSize2.getSelectionModel().getSelectedItem();
		CakeType size = studentService.getCakeType(sizelist);

		System.out.println("toplist" + toplist);
		System.out.println("size" + sizelist);
		System.out.println("Room Value" + choiceBoxLocation.getSelectionModel().getSelectedItem());

		String location = choiceBoxLocation.getSelectionModel().getSelectedItem().toString();
		// studentService.makeOrder(room, size, top);
		if (toplist.equals(null) || toplist.isEmpty()) {
			message.setText("Please select the toppings");
		} else if (size.equals(null) || size.equals("")) {
			message.setText("Please select the size");

		} else if ((location.isEmpty())) {
			message.setText("Please select the correct location");
		} else {
			studentService.makeOrder(location, size, top);
		}

	}

}
