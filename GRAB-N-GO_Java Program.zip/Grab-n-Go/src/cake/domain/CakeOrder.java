package cake.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the CAKE_ORDERS_TABLE database table.
 * 
 */
@Entity
@Table(name="CAKE_ORDERS_TABLE")
public class CakeOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@TableGenerator(name="OrderNumberGen",
			table = "CAKE_ID_GEN",
			pkColumnName = "GEN_NAME",
			valueColumnName = "GEN_VAL",
			pkColumnValue = "Ordno_Gen")
	@GeneratedValue(generator="OrderNumberGen")
	@Column(unique=true, nullable=false)
	private int id;

	@Column(nullable=false)
	private int day;

	@Column(name="Location", nullable=false)
	private String location;

	@Column(nullable=false)
	private int status;
	
	// Added to generated class: CAKE order status values--
 	public static final int PREPARING = 1;
 	public static final int BAKED = 2;
 	public static final int FINISHED = 3;
 	public static final int NO_SUCH_ORDER = 0;
 	private static final String[] STATUS_NAME = { "NO_SUCH_ORDER", 
         "PREPARING", 
         "BAKED",
         "FINISHED"
         };  

	//uni-directional many-to-many association to Topping
    @ManyToMany
	@JoinTable(
		name="ORDER_TOPPINGS"
		, joinColumns={
			@JoinColumn(name="ORDER_ID", nullable=false)
			}
		, inverseJoinColumns={
			@JoinColumn(name="TOPPING_ID", nullable=false)
			}
		)
	private Set<Topping> toppings;

	//uni-directional many-to-one association to cakeSize
    @ManyToOne
	@JoinColumn(name="TYPE_ID", nullable=false)
	private CakeType cakeType;

    public CakeOrder() {
    }
    
 	/** full constructor, except id: leave it null, JPA provider fills it in */
    public CakeOrder(CakeType cakeType, String location, int day, int status, Set<Topping> toppings) {
       this.location = location;
       this.cakeType = cakeType;
       this.day = day;
       this.status = status;
       this.toppings = toppings;
    }
	
	public void makeReady()
	{
		status = BAKED;
	}
	
	public void receive()
	{
		assert(status == BAKED);
		status = FINISHED;
	}

	public void finish()
	{
		status = FINISHED;
	}

	public int getId() {
		return this.id;
	}

	public int getDay() {
		return this.day;
	}

	public String getlocation() {
		return this.location;
	}

	public int getStatus() {
		return this.status;
	}


	public Set<Topping> getToppings() {
		return this.toppings;
	}

	
	public CakeType getCakeType() {
		return this.cakeType;
	}

	// string equivalent of status code
	public String statusString()
	{
		return STATUS_NAME[status];
	}
	
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("ORDER ID: " + getId() + "\n");
		buffer.append("ORDER DAY: " + getDay() + "\n");
		buffer.append("SIZE: " + (getCakeType() != null?getCakeType().getflavour():"not available") + "\n");
		buffer.append("ROOM NUMBER: " + getlocation() + "\n");
		buffer.append("STATUS: " + statusString());
		return buffer.toString();
	}

}