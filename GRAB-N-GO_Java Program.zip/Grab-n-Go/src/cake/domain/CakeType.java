package cake.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * @author Shiv
 * This file will manage flavors for admin 
 *
 */
@Entity
//@Entity(name = "CakeType")
@Table(name = "cake_types", uniqueConstraints = @UniqueConstraint(columnNames = "flavour"))

public class CakeType implements Serializable, Comparable<CakeType> {
	private static final long serialVersionUID = 1L;

	@Id
	@TableGenerator(name = "SizeIdGen", table = "CAKE_ID_GEN", pkColumnName = "GEN_NAME", valueColumnName = "GEN_VAL", pkColumnValue = "SizeId_Gen")
	@GeneratedValue(generator = "SizeIdGen")
	@Column(unique = true, nullable = false)
	private int id;

	@Column(name = "S_STATUS", nullable = false)
	private int status;

	@Column(name = "flavour", nullable = false, length = 30)
	private String flavour;

	public CakeType() {
	}

	public CakeType(String flavour) {
		this.status = 1;
		this.flavour = flavour;
	}

	public int getId() {
		return this.id;
	}

	public int getStatus() {
		return this.status;
	}

	// only for use in DAO
	public void setStatus(int status) {
		this.status = status;
	}

	public String getflavour() {
		return this.flavour;
	}

	@Override
	public int compareTo(CakeType x) {
		return getflavour().compareTo(x.getflavour());
	}

	@Override
	public boolean equals(Object x) {
		if (x == null || x.getClass() != getClass())
			return false;
		return getflavour().equals(((CakeType) x).getflavour());
	}

	@Override
	public int hashCode() {
		return getflavour().hashCode();
	}

	public String getFlavour() {
		return flavour;
	}

	public void setFlavour(String flavour) {
		this.flavour = flavour;
	}
}