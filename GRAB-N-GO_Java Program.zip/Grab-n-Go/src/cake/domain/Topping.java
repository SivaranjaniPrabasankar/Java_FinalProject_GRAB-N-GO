package cake.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.*;



/**
 * @author Shiv
 * This file will manage topping for admin
 *
 */
@Entity
@Table(name="cake_toppings",
	uniqueConstraints = @UniqueConstraint(columnNames="TOPPING_NAME"))
	
public class Topping implements Serializable, Comparable<Topping> {
	private static final long serialVersionUID = 1L;

	@Id
	@TableGenerator(name="ToppingIdGen",
			table = "CAKE_ID_GEN",
			pkColumnName = "GEN_NAME",
			valueColumnName = "GEN_VAL",
			pkColumnValue = "ToppingId_Gen")
				
	@GeneratedValue(generator="ToppingIdGen")
	@Column(unique=true, nullable=false)
	private int id;

	@Column(name="TOPPING_NAME", nullable=false, length=30)
	private String toppingName;

    public Topping() {
    }
    
	/** create non-deleted Topping, id is handled by JPA */
    public Topping(String toppingName) {
        this.toppingName = toppingName;
    }
    
	public int getId() {
		return this.id;
	}

	public String getToppingName() {
		return this.toppingName;
	}

	
	public int compareTo(Topping x)
	{
		return getToppingName().compareTo(x.getToppingName());
	}
	@Override
	public boolean equals(Object x)
	{
		if (x == null || x.getClass()!= getClass())
			return false;
		return getToppingName().equals(((Topping)x).getToppingName());
	}
	@Override
	public int hashCode()
	{
		return getToppingName().hashCode();
	}
}