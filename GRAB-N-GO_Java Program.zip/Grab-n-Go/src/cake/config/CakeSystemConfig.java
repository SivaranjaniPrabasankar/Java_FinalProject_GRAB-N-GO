package cake.config;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.mysql.jdbc.Connection;

import cake.dao.AdminDAO;
import cake.dao.DbDAO;
import cake.dao.CakeOrderDAO;
import cake.service.AdminService;
import cake.service.StudentService;

public class CakeSystemConfig {
	public static final int NUM_OF_ROOMS = 10;
	private static AdminService adminService;
	private static StudentService studentService;

	private static EntityManagerFactory emf;
	public static void configureServices() throws RuntimeException {
		try {
			emf = configureJPA(); 
			testEMF(emf); 
			System.out.println("calling dbDAO constructor");
			DbDAO dbDAO = new DbDAO(emf);
			AdminDAO adminDAO = new AdminDAO(dbDAO);
			CakeOrderDAO cakeOrderDAO = new CakeOrderDAO(dbDAO);
			adminService = new AdminService(dbDAO, adminDAO, cakeOrderDAO);
			studentService = new StudentService(dbDAO, cakeOrderDAO, adminDAO);
		} catch (Exception e) {
			System.out.println("Problem with contacting DB");
			throw (e);
		}
	}
	
	public static EntityManagerFactory configureJPA() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("cake");
		return emf;
	}
	
	private static void testEMF(EntityManagerFactory emf)
	{
		System.out.println("starting testEMF");
		EntityManager em = emf.createEntityManager();
		System.out.println("testEMF: Got an EM");
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		try {
			System.out.println("testEM: Trying to get JDBC Connection from EM...");
			Connection conn = em.unwrap(Connection.class);  
			System.out.println("testEM: ...OK: JDBC isolation level (0=none,1=RU,2=RC,4=RR,8=SR) is " 
					+ conn.getTransactionIsolation());
			tx.commit();
			em.close();
		} catch (Exception e) {
			System.out.println(" Exception trying to get isolation level: " + e + "\n Continuing...");
		}
	}
	public static String exceptionReport(Exception e) {
		String message = e.toString(); // exception name + message
		if (e.getCause() != null) {
			message += "\n  cause: " + e.getCause();
			if (e.getCause().getCause() != null) {
				message += "\n    cause's cause: " + e.getCause().getCause();
			}
		}
		message += "\n Stack Trace: "
						+ exceptionStackTraceString(e);
		return message;
	}
	
	private static String exceptionStackTraceString(Throwable e) {
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}
	
	public static void shutdownServices() {
		if (emf != null && !emf.isOpen())
			emf.close();
	}
	
	
	public static AdminService getAdminService() {
		return adminService;
	}

	public static StudentService getStudentService() {
		return studentService;
	}

}
