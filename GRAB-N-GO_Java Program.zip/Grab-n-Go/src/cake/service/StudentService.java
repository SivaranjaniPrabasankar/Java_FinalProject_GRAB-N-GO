package cake.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cake.dao.AdminDAO;
import cake.dao.DbDAO;
import cake.dao.CakeOrderDAO;
import cake.domain.CakeOrder;
import cake.domain.CakeType;
import cake.domain.Topping;
import javafx.collections.ObservableList;

public class StudentService {

	private CakeOrderDAO cakeOrderDAO;

	private AdminDAO adminDAO;

	private DbDAO dbDAO;

	public StudentService(DbDAO dbDAO, CakeOrderDAO cakeDAO,
			AdminDAO admDAO) {
		this.dbDAO = dbDAO;
		cakeOrderDAO = cakeDAO;
		adminDAO = admDAO;
	}
	public Set<CakeType> getCakeTypes()throws ServiceException
	{
		Set<CakeType> sizes = null;
		try {
            dbDAO.startTransaction();  
			sizes = cakeOrderDAO.findCakeType();

            dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException(); 
			throw new ServiceException("Can't access cake types in db: ", e);
		}
	   return sizes;	
	}

	public Set<Topping> getToppings()throws ServiceException
	{
		Set<Topping> toppings = null;
		try {
            dbDAO.startTransaction();  
			toppings = cakeOrderDAO.findToppings();
            dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException(); 
			throw new ServiceException("Can't access toppings in db: ", e);
		}
		return toppings;
	}

	
	public void makeOrder(String location, CakeType size, Set<Topping> toppings) 
				throws ServiceException {
		try {	
			dbDAO.startTransaction(); 
			
			CakeType orderSize;
			if ((orderSize = cakeOrderDAO.findCakeType(size.getflavour())) == null) 
				throw new ServiceException(
						"Order cannot be placed because specified size " + size.getflavour() + " is unavailable");
			Set<Topping> orderToppings = new HashSet<Topping>();
			Topping t1;
			for (Topping t:toppings)
				if ((t1 = cakeOrderDAO.findTopping(t.getToppingName())) == null)
					throw new ServiceException(
							"Order cannot be placed because specified topping " + t.getToppingName() + " is unavailable");
				else
					orderToppings.add(t1);  // it's OK, collect it up
			
			CakeOrder order = new CakeOrder(orderSize, location, 
					adminDAO.findCurrentDay(), CakeOrder.PREPARING, orderToppings);
			cakeOrderDAO.insertOrder(order);
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Order can not be placed ", e);
		}
	}

	
	public List<CakeOrderData> getOrderStatus(String location)
			throws ServiceException {
		List<CakeOrder> cakeOrders = null;
		List<CakeOrderData> cakeOrders1 = new ArrayList<CakeOrderData>();
		try {
			dbDAO.startTransaction(); 																				
			cakeOrders = cakeOrderDAO.findOrdersByRoom(location, adminDAO
					.findCurrentDay());

			for (CakeOrder order : cakeOrders) {
				cakeOrders1.add(new CakeOrderData(order));
	
				
				for (Topping t: order.getToppings())
				    t.getToppingName();
			}
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Error in getting status ", e);
		}
		return cakeOrders1;
	}
	
	
	public void receiveOrders(String roomNumber)throws ServiceException {
		List<CakeOrder> cakeOrders = null;
		try {
			dbDAO.startTransaction(); 	
			cakeOrders = cakeOrderDAO.findOrdersByRoom(roomNumber, adminDAO.findCurrentDay());
			for (CakeOrder order: cakeOrders) {
				if (order.getStatus()== CakeOrder.BAKED) {
					order.receive();	// mark this cake "finished"
								
				}
			}
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Error in getting status" + e, e);
		}
	}

	public Set<Topping> getToppingsType(ObservableList<String> toppingNames)throws ServiceException
	{
		Topping tops = null;
		Set<Topping> toppings = null;
		try {
            dbDAO.startTransaction();  
            for (String t1:toppingNames){
            	toppings =  cakeOrderDAO.findToppings(t1);
            }
			System.out.println("Topping  " +toppings);
			
            dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException(); 
			throw new ServiceException("Can't access toppings in db: ", e);
		}
		return toppings;
	}
	public CakeType getCakeType(String sizeName)throws ServiceException{
		
		CakeType size = new CakeType();

		try {
            dbDAO.startTransaction();  
			size = cakeOrderDAO.findCakeType(sizeName);
            dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException(); 
			throw new ServiceException("Can't access cake sizes in db: ", e);
		}
	   return size;	
	
	}
}
