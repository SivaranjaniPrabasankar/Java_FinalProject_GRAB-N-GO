package cake.service;

import java.util.ArrayList;
import java.util.List;

import cake.dao.AdminDAO;
import cake.dao.DbDAO;
import cake.dao.CakeOrderDAO;
import cake.domain.CakeOrder;
import cake.domain.Topping;

public class AdminService {

	private DbDAO dbDAO;
	private AdminDAO adminDAO;
	private CakeOrderDAO cakeOrderDAO;

	public AdminService(DbDAO db, AdminDAO admDAO, CakeOrderDAO poDAO) {
		dbDAO = db;
		adminDAO = admDAO;
		cakeOrderDAO = poDAO;
	}

	public void initializeDb() throws ServiceException {
		try {
			dbDAO.startTransaction();
			dbDAO.initializeDb();
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException(
					"Can't initialize DB: (probably need to load DB)", e);
		}
	}

	public void addTopping(String name) throws ServiceException {
		try {
			dbDAO.startTransaction();
			cakeOrderDAO.createTopping(name);
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Topping was not added successfully: ",
					e);
		}
	}

	public void removeTopping(String topping) throws ServiceException {
		try {
			dbDAO.startTransaction();
			cakeOrderDAO.deleteTopping(topping);
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Error while removing topping ", e);
		}
	}

	
	public void addCakeSize(String name) throws ServiceException {
		try {
			dbDAO.startTransaction();
			cakeOrderDAO.createCakeType(name);
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Cake size was not added successfully",
					e);
		}
	}

	public void removeCakeSize(String size) throws ServiceException {
		try {
			dbDAO.startTransaction();
			cakeOrderDAO.deleteCakeType(size);
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Error while removing topping", e);
		}
	}

	public void markNextOrderReady() throws ServiceException {
		CakeOrder order = null;
		try {
			dbDAO.startTransaction();
			order = cakeOrderDAO.findFirstOrder(CakeOrder.PREPARING);
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Error in marking the next order ready",
					e);
		}
		if (order == null) {
			throw new ServiceException("No PREPARING orders exist!");
		}
		order.makeReady(); // this change is tracked by JPA
		try {
			dbDAO.commitTransaction(); // update occurs here
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException(
					"Error at commit in marking the next order ready", e);
		}
	}

	public int getCurrentDay() throws ServiceException {
		int day;
		try {
			dbDAO.startTransaction(); // read-only
			day = adminDAO.findCurrentDay();
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Can't access date in db: ", e);
		}
		return day;
	}

	public void advanceDay() throws ServiceException {
		try {
			dbDAO.startTransaction();
			List<CakeOrder> cakeOrders = getTodaysOrders();
			// day is done, so mark today's cakes as "finished"
			for (CakeOrder order : cakeOrders) {
				order.finish();
			}
			adminDAO.advanceDay();
			dbDAO.commitTransaction();
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Unsuccessful advance day", e);
		}
	}

	// helper method to advanceDay
	// executes inside the current transaction
	private List<CakeOrder> getTodaysOrders() {
		int today = adminDAO.findCurrentDay();
		List<CakeOrder> orders = cakeOrderDAO.findOrdersByDays(today, today);
		return orders;
	}

	public List<CakeOrderData> getOrdersByDay(int day) throws ServiceException {
		try {
			dbDAO.startTransaction();
			List<CakeOrder> orders = cakeOrderDAO.findOrdersByDays(day, day);
			List<CakeOrderData> orders1 = new ArrayList<CakeOrderData>();
			for (CakeOrder o : orders) {
				orders1.add(new CakeOrderData(o));
			}
			dbDAO.commitTransaction();
			return orders1;
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Error while getting daily report ", e);
		}
	}

	public List<CakeOrderData> getTodaysOrdersByStatus(int status)
			throws ServiceException {
		try {
			dbDAO.startTransaction();
			List<CakeOrder> orders = getTodaysOrders();	
			dbDAO.commitTransaction();
			List<CakeOrderData> orders1 = new ArrayList<CakeOrderData>();
			for (CakeOrder o : orders) {
				if (o.getStatus() == status)
					orders1.add(new CakeOrderData(o));
			}		
			return orders1;
		} catch (Exception e) {
			dbDAO.rollbackAfterException();
			throw new ServiceException("Error while getting daily report ", e);
		}
	}

}
