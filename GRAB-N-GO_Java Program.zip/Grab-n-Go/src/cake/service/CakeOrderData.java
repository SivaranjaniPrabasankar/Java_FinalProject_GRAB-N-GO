package cake.service;



import java.util.Set;

import cake.domain.CakeOrder;
import cake.domain.CakeType;
import cake.domain.Topping;
	
/**
 * @author Shiv
 * This file will manage orders for users
 *
 */
public class CakeOrderData {
	private String location;
	private CakeType cakeSize;
	private Set<Topping> toppings;
	private int id;
	private int day;
	private int status;
	private String statusString;
	public static final int PREPARING = 1;
	public static final int BAKED = 2;
	public static final int FINISHED = 3;
	public static final int NO_SUCH_ORDER = 0;

	public CakeOrderData(int id, String location, CakeType size,
			Set<Topping> toppings, int day, int status, String statusString) {
		this.location = location;
		this.cakeSize = size;
		this.id = id;
		this.day = day;
		this.status = status;
		this.toppings = toppings;
	}
	
	public CakeOrderData(CakeOrder po) {	
		this.location = po.getlocation();
		this.cakeSize = po.getCakeType();
		this.id = po.getId();
		this.day = po.getDay();
		this.status = po.getStatus();
		this.statusString = po.statusString();
		this.toppings = po.getToppings();
	}
	
	public Set<Topping> getToppings()
	{
		return toppings;
	}
			
	public int getDay() {
		return day;
	}

	public String getLocation() {
		return location;
	}

	public CakeType getCakeSize() {
		return cakeSize;
	}

	public int getId() {
		return id;
	}

	public int getStatus() {
		return status;
	}

	public String getStatusString() {
		return statusString;
	}
	
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("ORDER ID: " + getId() + "\n");
		buffer.append("ORDER DAY: " + getDay() + "\n");
		if (getCakeSize() != null) 
			buffer.append("SIZE: " + getCakeSize() + "\n");
		if (getToppings() != null) {
			buffer.append("TOPPINGS: ");
			for (Topping t: getToppings()) {
				buffer.append(t);
				buffer.append(" ");
			}
			buffer.append("\n");
		}
		buffer.append("LOCATION: " + getLocation() + "\n");
		buffer.append("STATUS: " + getStatusString());
		return buffer.toString();
	}
}
