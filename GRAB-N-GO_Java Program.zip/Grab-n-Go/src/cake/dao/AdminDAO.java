package cake.dao;

import static cake.dao.DBConstants.SYS_TABLE;

import javax.persistence.EntityManager;
import javax.persistence.Query;


public class AdminDAO {

	private DbDAO dbDAO;

	public AdminDAO(DbDAO db) {
		dbDAO = db;
	}

	

	public void advanceDay() {
		EntityManager em = dbDAO.getEM();
		Query q = em.createNativeQuery("update " + SYS_TABLE
				+ " set current_day = current_day + 1");
		q.executeUpdate();
	}
	
	public int findCurrentDay() {
		EntityManager em = dbDAO.getEM();
		Query q = em.createNativeQuery("select current_day from " + SYS_TABLE);
		
		int day = ((Number) q.getSingleResult()).intValue();
		return day;
	}



}
