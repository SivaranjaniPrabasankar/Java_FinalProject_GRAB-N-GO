package cake.dao;
/**
 *
 * Data access class for Cake order objects, including their sizes and toppings
 */

import java.util.Set;
import java.util.TreeSet;

import static cake.dao.DBConstants.*;

import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import cake.domain.CakeOrder;
import cake.domain.CakeType;
import cake.domain.Topping;

public class CakeOrderDAO {

	private DbDAO dbDAO;

	public CakeOrderDAO(DbDAO db) {
		this.dbDAO = db;
	}

	public void insertOrder(CakeOrder order) {
		dbDAO.getEM().persist(order);
	}

	public List<CakeOrder> findOrdersByRoom(String location, int day) {
		TypedQuery<CakeOrder> query = dbDAO.getEM().createQuery(
				"select o from CakeOrder o where o.location = '" + location + "' and o.day = " + day + " order by o.id",
				CakeOrder.class);
		List<CakeOrder> orders = query.getResultList();
		return orders;
	}

	public CakeOrder findFirstOrder(int status) {
		TypedQuery<CakeOrder> query = dbDAO.getEM().createQuery(
				"select o from CakeOrder o where o.status = " + status + " order by o.id", CakeOrder.class);
		List<CakeOrder> orders = query.getResultList();
		if (orders.isEmpty())
			return null;
		else
			return orders.get(0);
	}

	public List<CakeOrder> findOrdersByDays(int day1, int day2) {
		TypedQuery<CakeOrder> query = dbDAO.getEM().createQuery(
				"select o from CakeOrder o where o.day >= " + day1 + " and o.day <= " + day2 + " order by o.id",
				CakeOrder.class);
		List<CakeOrder> orders = query.getResultList();
		return orders;
	}

	public void createTopping(String toppingName) {
		EntityManager em = dbDAO.getEM();
		Query query = em.createNativeQuery(
				"update " + TOPPING_TABLE + " set t_status = 1 where topping_name = '" + toppingName + "'");
		int rows = query.executeUpdate();
		if (rows == 0) {
			em.persist(new Topping(toppingName));
		}
	}

	public void createCakeType(String typeName) {
		EntityManager em = dbDAO.getEM();
		System.out.println("in createCakeSize");
		TypedQuery<CakeType> query = em.createQuery("select s from CakeType s where s.flavour = '" + typeName + "'",
				CakeType.class);
		List<CakeType> sizes = query.getResultList();
		if (sizes.size() > 0) {
			sizes.get(0).setStatus(1);
		} else { // create new size
			em.persist(new CakeType(typeName));
		}
	}

	@SuppressWarnings("unchecked")
	public Topping findTopping(String toppingName) {
		EntityManager em = dbDAO.getEM();
		Query query = em.createNativeQuery("select id, topping_name from cake_toppings t where topping_name = '"
				+ toppingName + "' and t_status = 1", Topping.class);
		List<Topping> tops = (List<Topping>) query.getResultList();
		if (tops.size() == 0)
			return null;
		return tops.get(0);
	}

	@SuppressWarnings("unchecked")
	public Set<Topping> findToppings(String toppingName) {
		EntityManager em = dbDAO.getEM();
		Query query = em.createNativeQuery("select id, topping_name from cake_toppings t where topping_name = '"
				+ toppingName + "' and t_status = 1", Topping.class);
		List<Topping> tops = (List<Topping>) query.getResultList();
		if (tops.size() == 0)
			return null;
		return new TreeSet<Topping>(tops);

	}

	public CakeType findCakeType(String typeName) {
		EntityManager em = dbDAO.getEM();
		TypedQuery<CakeType> query = em.createQuery(
				"select s from CakeType s where s.flavour = '" + typeName + "' and s.status = 1", CakeType.class);
		List<CakeType> sizes = query.getResultList();
		if (sizes.size() == 0)
			return null;
		return sizes.get(0);
	}

	public void deleteTopping(String toppingName) {
		EntityManager em = dbDAO.getEM();
		Query query = em.createNativeQuery(
				"update " + TOPPING_TABLE + " set t_status = 0 where topping_name = '" + toppingName + "'");
		int nRows = query.executeUpdate();
		if (nRows == 0)
			throw new RuntimeException("Attempted delete of nonexistent topping");
	}

	public void deleteCakeType(String typeName) {
		CakeType type = findCakeType(typeName);
		if (type != null)
			type.setStatus(0);
		else
			throw new RuntimeException("Attempted delete of nonexistent size");
	}

	@SuppressWarnings("unchecked")
	public Set<Topping> findToppings() {
		EntityManager em = dbDAO.getEM();

		Query query = em.createNativeQuery("select id, topping_name from cake_toppings t where t_status = 1",
				Topping.class);
		List<Topping> tops = (List<Topping>) query.getResultList();

		return new TreeSet<Topping>(tops);
	}

	public Set<CakeType> findCakeType() {
		EntityManager em = dbDAO.getEM();
		 
		Query query = em.createNativeQuery("select id, flavour from cake_types s where s_status = 1", CakeType.class);
		List<CakeType> types = (List<CakeType>)query.getResultList();
		return new TreeSet<CakeType>(types);
	}

}
