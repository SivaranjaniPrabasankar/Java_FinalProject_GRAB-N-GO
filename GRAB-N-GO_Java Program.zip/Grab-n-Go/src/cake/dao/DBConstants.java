package cake.dao;



public interface DBConstants {


public static final String ORDER_TABLE = "cake_orders_table";
public static final String SYS_TABLE = "cake_system_tab";
public static final String TOPPING_TABLE = "cake_toppings";
public static final String TOPPING_ORDER_TABLE = "order_toppings";
public static final String CAKE_TYPE_TABLE = "cake_types";
public static final int MAX_TOPPINGS_STR_SIZE = 30;
public static final int MAX_SIZE_STR_SIZE = 30;

public static final String CAKE_ID_GEN_TABLE = "cake_id_gen";
public static final String[] CAKE_GEN_NAMES = {"Ordno_Gen", "SizeId_Gen", "ToppingId_Gen"};
}
