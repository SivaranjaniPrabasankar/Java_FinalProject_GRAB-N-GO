package cake.dao;

import static cake.dao.DBConstants.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

public class DbDAO {
	private EntityManagerFactory emf;
	private EntityManager em;

	public EntityManager getEM() {
		return em;
	}

	public DbDAO(EntityManagerFactory emf) {
		this.emf = emf;
	}

	public void initializeDb() {
		
		clearTable(TOPPING_ORDER_TABLE);
		clearTable(TOPPING_TABLE);
		clearTable(ORDER_TABLE);
		clearTable(CAKE_TYPE_TABLE);
		clearTable(SYS_TABLE);
		clearTable(CAKE_ID_GEN_TABLE);
		
		initSysTable();
		initIdGenTable();
	}

	
	private void clearTable(String tableName) {
		Query q = em.createNativeQuery("delete from " + tableName);
		int n = q.executeUpdate(); // SQL of update shows in FINE logging
		System.out.println("deleted " + n + " rows from " + tableName);
	}

	private void initSysTable() {
		System.out.println("inserting row (1,1) into " + SYS_TABLE);
		Query q = em.createNativeQuery("insert into " + SYS_TABLE
				+ " values (1,1)");
		int n = q.executeUpdate();
		System.out.println("inserted " + n + " rows into " + SYS_TABLE);
	}
	
	
	private void initIdGenTable() {
		for (int i = 0; i < CAKE_GEN_NAMES.length; i++)
			initIdGenTableOneRow(CAKE_GEN_NAMES[i]);
	}
	private void initIdGenTableOneRow(String genName) {
		System.out.println("inserting row (" + genName + ", 0) into " + CAKE_ID_GEN_TABLE);
		Query q = em.createNativeQuery(
				"insert into " + CAKE_ID_GEN_TABLE + " values ('" + genName + "', 0)");
		int n = q.executeUpdate();
		System.out.println("inserted " + n + " rows into " + SYS_TABLE);
	}
	public void startTransaction() {
		em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
	}

	public void commitTransaction() {
		
		em.getTransaction().commit();
		
		em.close(); 
	}

	public void rollbackTransaction() {
		try {
			em.getTransaction().rollback();
		} finally {
			em.close();
		}
	}

	
	public void rollbackAfterException() {
		try {
			rollbackTransaction();
		} catch (Exception e) {
			
		}
	}
}
