package cake;
	
import java.io.IOException;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application {

	protected Parent root,root2;
    protected Scene scene;
    protected Stage primaryStage;
    public static Main instance;

    public Main(){
        instance = this;
    }
    public static Main getInstance(){
        return instance;
    }
    
	@Override
	public void start(Stage primaryStge) {
		primaryStage = primaryStge;
        try {
			changeStage("/cake/presentation/Login.fxml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	 public void changeStage(String fxmlAdress ) throws IOException{
		 
	        root = FXMLLoader.load(getClass().getResource(fxmlAdress));
	        scene = new Scene(root);
	        primaryStage.setScene(scene);
	        
	        primaryStage.setTitle("Welcome to Cake Shop!");
	        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());

	        primaryStage.show();        
	    }
	
	public static void main(String[] args) {
			launch(args);
	}
}
